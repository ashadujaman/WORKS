<?php

                        if(isset($_REQUEST['Buy']))
                          {
                         header( 'Location:../order.php'); 

                          }
                     else
                           {
 
                           header( 'Location:../UserLogin.php'); 
                               }
                                             
 
                           
    

?>