<!DOCTYPE html> 
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


</head>
<body class="col-lg-11.5">







 <nav class="navbar navbar-expand-sm bg-success navbar-dark">

<h1>Daily Outfit Attire</h1> 
<div  style="text-align:right;">
<ul class="navbar-nav ml-auto ">
     <h3> .... </h3>
    <h3 class="nav-item active"><a class="nav-link"href="MainHome.php">Home</a></h3>
     <h3> .... </h3>
    <h3 class="nav-item"><a class="nav-link" href="signup.php">Signup</a></h3>
     <h3> .... </h3>
    <h3  class="nav-item"><a class="nav-link"  href="UserLogin.php">LogIn</a></h3>
</ul>
</div>
</nav>





<section class="container">


   
        <div class="row row-cols-1 row-cols-md-2 row-cols-md-3 ">
            <div class="col-lg-4 mr-1  ">
                <a href="Product.php">
        <img class="img-fluid w-80"id="101" src="image/black.png"/> </a>
        <P class="text-center">Black T-shirt</P>
        <p class="text-muted text-center">৳90000</p>

        </div>
        <div class="col-lg-4 ">
            <a href="Product2.php">
        <img class="img-fluid w-80" id="102" src="image/White.png"/></a>
        <p class="text-center">White T-shirt</p>
        <p class="text-muted text-center">৳80000</p>

        </div>
        <div class="col-lg-4 ">
            <a href="Product3.php">
        <img class="img-fluid w-80" id="103" src="image/pant.jpg"/></a>
        <p class="text-center">Formal Pant</p>
        <p class="text-muted text-center">৳85000TK</p>

    </div>
</div> 


</section>

</body>
</html>

<?php
include"footer.php";
?>